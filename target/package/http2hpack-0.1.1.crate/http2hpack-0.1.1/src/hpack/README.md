## HPACK

Header compression that is defined in RFC: https://tools.ietf.org/html/rfc7541

Uses Huffman encoding/decoding.
