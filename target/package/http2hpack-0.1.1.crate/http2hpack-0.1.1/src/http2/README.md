## HTTP/2

Module to support http/2 parsing etc.

Based on RFC: https://tools.ietf.org/html/rfc7540

There may be extension also added to support APIs and API signatures similar to AWS V4.
