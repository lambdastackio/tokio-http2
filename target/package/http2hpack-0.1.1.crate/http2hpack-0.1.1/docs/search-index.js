var searchIndex = {};
searchIndex["http2hpack"] = {"doc":"This library supplies the required modules to implement HTTP/2 which includes the HPACK header\ncompression that includes the Huffman encoding/decoding features.","items":[[0,"http2","http2hpack","This library module provides HTTP/2 parsing and buffer frames used for HTTP/2.",null,null],[0,"hpack","","This library module provides the required HPACK compression used for HTTP/2 headers.",null,null]],"paths":[]};
initSearch(searchIndex);
